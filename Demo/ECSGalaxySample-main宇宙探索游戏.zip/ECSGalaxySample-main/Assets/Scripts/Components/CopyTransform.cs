using Unity.Entities;

public struct CopyEntityLocalTransformAsLtW : IComponentData
{
    public Entity TargetEntity;
}
