using Unity.Entities;

public struct MainCamera : IComponentData
{
}
