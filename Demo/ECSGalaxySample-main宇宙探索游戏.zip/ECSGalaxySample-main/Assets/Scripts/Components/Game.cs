using Unity.Entities;

public struct SpatialDatabaseSingleton : IComponentData
{
    public Entity TargetablesSpatialDatabase;
}
