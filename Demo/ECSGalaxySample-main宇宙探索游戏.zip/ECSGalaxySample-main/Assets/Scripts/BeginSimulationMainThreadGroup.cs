using Unity.Entities;

public partial class BeginSimulationMainThreadGroup : ComponentSystemGroup
{ }
