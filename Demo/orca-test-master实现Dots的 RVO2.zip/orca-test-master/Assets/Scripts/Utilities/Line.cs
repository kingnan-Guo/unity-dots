﻿using Unity.Mathematics;

public struct Line
{
    public float2 direction;
    public float2 point;
}