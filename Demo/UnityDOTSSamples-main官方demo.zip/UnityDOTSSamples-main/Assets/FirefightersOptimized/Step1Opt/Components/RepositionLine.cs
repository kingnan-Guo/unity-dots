using Unity.Entities;

namespace FirefightersOptimized.Components
{
    public struct RepositionLine : IComponentData, IEnableableComponent
    {
        
    }
}