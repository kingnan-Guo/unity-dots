using Unity.Burst;
using Unity.Entities;

namespace Benchmark3_SharedStatic.Scripts.SystemGroups
{
    [DisableAutoCreation]
    public partial class SharedStaticDataUpdateSystemGroup : ComponentSystemGroup
    {
    }
}