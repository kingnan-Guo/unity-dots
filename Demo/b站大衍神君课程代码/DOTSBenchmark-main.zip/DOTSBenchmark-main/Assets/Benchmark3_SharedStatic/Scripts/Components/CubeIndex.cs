using Unity.Entities;

namespace Benchmark3_SharedStatic.Scripts.Components
{
    public struct CubeIndex : IComponentData
    {
        public int index;
    }
}