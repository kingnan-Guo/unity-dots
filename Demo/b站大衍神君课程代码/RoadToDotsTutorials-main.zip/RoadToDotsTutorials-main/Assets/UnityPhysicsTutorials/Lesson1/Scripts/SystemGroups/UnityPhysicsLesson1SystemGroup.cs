using DOTS.DOD.GRAPHICS;

namespace DOTS.PHYSICS.LESSON0
{
    public partial class UnityPhysicsLesson1SystemGroup : SceneSystemGroup
    {
        protected override string SceneName => "CreatePhysicsWorldRuntime";
    }
}
