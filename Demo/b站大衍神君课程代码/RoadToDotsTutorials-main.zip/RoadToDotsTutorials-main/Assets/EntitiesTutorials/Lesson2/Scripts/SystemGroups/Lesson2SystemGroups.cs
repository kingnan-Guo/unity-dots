namespace DOTS.DOD.LESSON2
{
    public partial class CubeRotateWithIJobEntitySystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "RotateCubeWithIJobEntity";
    }
    
    public partial class CubeRotateWithIJobChunkSystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "RotateCubeWithIJobChunk";
    }
}