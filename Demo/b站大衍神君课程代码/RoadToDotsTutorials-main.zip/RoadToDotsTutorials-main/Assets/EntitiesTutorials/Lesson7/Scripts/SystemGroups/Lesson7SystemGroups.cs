
namespace DOTS.DOD.LESSON7
{
    public partial class CubesMarchSystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "CubesMarch";
    }
}
