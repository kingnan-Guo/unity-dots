namespace DOTS.DOD.LESSON8
{
    public partial class MultiCubesMarchSystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "MultiCubesMarch";
    }
}

