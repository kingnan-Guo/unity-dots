

using Unity.Entities;

namespace DOTS.DOD.LESSON11
{
    public partial class Lesson11SystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "GenerateChunkComponent";
    }
}

