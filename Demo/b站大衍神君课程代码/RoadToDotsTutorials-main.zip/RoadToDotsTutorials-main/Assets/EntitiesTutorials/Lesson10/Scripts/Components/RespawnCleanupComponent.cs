using Unity.Entities;
using UnityEngine;

namespace DOTS.DOD.LESSON10
{
    struct RespawnCleanupComponent : ICleanupComponentData
    {
    }
}
