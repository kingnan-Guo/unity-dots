
namespace DOTS.DOD.LESSON6
{
    public partial class Lesson6SystemGroups : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "MoveCubesWithWayPoints";
    }
}

