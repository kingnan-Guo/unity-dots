using DOTS.DOD;

namespace DOTS.ADVANCED.ANTPHERMONES
{
    public partial class AntPhermonesSystemGroup : AuthoringSceneSystemGroup
    {
        protected override string AuthoringSceneName => "ant_dots";
    }
}

