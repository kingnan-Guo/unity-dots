using Unity.Entities;
using UnityEngine;

namespace DOTS.ADVANCED.ANTPHERMONES
{
    public struct ColonyID : ISharedComponentData
    {
        public int id;
    }
}

