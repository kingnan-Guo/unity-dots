using Unity.Entities;

namespace DOTS.ADVANCED.ANTPHERMONES
{
    public struct Pheromone : IBufferElementData
    {
        public float strength;
    }
}