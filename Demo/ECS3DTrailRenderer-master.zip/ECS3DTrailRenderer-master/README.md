# ECS3DTrailRenderer
[ECS完全に理解した勉強会](https://connpass.com/event/101774/)用のサンプルです

![capture](https://user-images.githubusercontent.com/3889597/47265937-9d78f600-d56a-11e8-8ed9-945e957aaa1b.gif)
